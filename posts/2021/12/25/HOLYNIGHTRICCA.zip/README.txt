﻿作品名：聖騎士リッカの物語　白翼と淫翼の姉妹
ＨＰ：https://www.dlsite.com/maniax//RJ297937


－使用方法－
「savefile.sav、system.sav」を「C:\Users\(UserName)\AppData\LocalLow\Mogurasoft\HolyKnightRicca」に上書き保存をしてください。


－効果－
(回想１００％％)


提供者：Ｋｏｕｅｎ
(https://kouen.live)